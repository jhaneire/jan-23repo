<?php
    $data = json_decode(file_get_contents('php://input'), true);
    // Get the form data
    $name = $data['name'];
    $email = $data['email'];
    $message = $data['message'];
    $name2 = $data['name2'];
    $email2 = $data['email2'];

    // Validate the name
    if (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        echo 'Invalid name';
        exit;
    }
    // Validate the email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Invalid email';
        exit;
    }
    // Validate the phone
    if (!preg_match('/^[0-9\s]+$/', $name2)) {
        echo 'Invalid phone';
        exit;
    }
    // Validate the subject
    if (!filter_var($email2, FILTER_VALIDATE_EMAIL)) {
        echo 'Invalid subject';
        exit;
    }

    // Sanitize the message
    $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

    <?php
    $data = json_decode(file_get_contents('php://input'), true);
    // Get the form data
    $name = $data['name'];
    $email = $data['email'];
    $message = $data['message'];
    $phone = $data['name2'];
    $subject = $data['email2'];

    // Validate the name
    if (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        echo 'Invalid name';
        exit;
    }

    // Validate the email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Invalid email';
        exit;
    }

    // Sanitize the message
    $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

    // Recipient email address
    $to = 'jcmendez187@gmail.com';

    // Message to be sent in the email
    $body = "Name: $name\nEmail: $email\nPhone: $phone\nSubject: $subject\n\nMessage:\n$message";

    // Additional headers
    $headers = "From: $name <$email>";

    // Send the email
    if (mail($to, $subject, $body, $headers)) {
        // If the email was sent successfully
        echo 'Success';
    } else {
        // If there was an error sending the email
        echo 'Error';
    }
?>

?>
